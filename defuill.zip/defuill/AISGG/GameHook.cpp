#include "pch.h"
#include "GameHook.h"
#include "AnimFixSystem.h"

void GameHook::initialize() {
    if (!initialized) {
        initialized = true;
        OutputDebugStringA("[GameHook] Initialized - Press R to clear animations\n");
    }
}

bool GameHook::isKeyPressed(int vKey) {
    if ((GetAsyncKeyState(vKey) & 0x8000) == 0) {
        return false;
    }
    unsigned long now = GetTickCount();
    if (now - lastKeyTime < KEY_DELAY_MS) {
        return false;
    }
    lastKeyTime = now;
    return true;
}

void GameHook::update() {
    if (isKeyPressed('R')) {
        AnimFixSystem::getInstance().clearAllAnimations();
    }
}
