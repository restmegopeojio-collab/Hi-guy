#pragma once

class AnimFixSystem {
public:
    static AnimFixSystem& getInstance() {
        static AnimFixSystem instance;
        return instance;
    }

    void initialize();
    void clearAllAnimations();

private:
    AnimFixSystem() : lastClearTime(0) {}
    unsigned long long lastClearTime;
    bool isValidPtr(DWORD addr) const;
};
