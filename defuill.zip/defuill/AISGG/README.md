# README.md

# GTA SA Animation Fix (AnimFix) ASI Plugin

An ASI plugin for GTA San Andreas that fixes stuck/glitched character animations, allowing your character to move freely when animations get bugged.

---

# How It Works

When GTA SA animations get stuck (e.g., from failed script events, animation conflicts, or server-side issues in SA:MP), the player character becomes frozen or locked into a pose. This mod:

1. **Runs in a dedicated background thread**
2. **Press R** to clear all active animations on the player ped
3. Blends idle/walk/run animations to restore normal movement

The mod calls the game's internal `CAnimManager::BlendAnimation` function to blend the player back to a normal animation state.

---

# Current Features

## Animation Fix System

* Reads player ped pointer (`0xB6F5F0`)
* Safely validates memory addresses before access
* Calls game function to blend idle/walk/run animations
* SEH exception handling (never crashes the game)
* Cooldown system (1 second between fixes)
* Key debounce (250ms) to prevent rapid key firing

## Hook System

* Game Hook abstraction with singleton pattern
* Safe initialization
* Thread-safe update loop with atomic shutdown
* Key debounce for reliable input handling

## Debug System

* Visual Studio Debug Output
* Runtime logging with detailed status messages
* SEH exception handling (never crashes the game)

---

# Architecture

```text
AISGG/

AnimFixSystem   - Animation state management & memory operations
GameHook        - Game integration layer & keyboard input
dllmain         - DLL entry point & thread loop
```

---

# Design Principles

* Stability first
* Clean architecture
* Modular systems
* Beginner friendly
* Easy to expand

---

# Controls

| Key | Action                  |
|-----|-------------------------|
| R   | Clear stuck animations  |

---

# Memory Addresses (GTA SA 1.0 US)

| Address    | Description                                  |
|------------|----------------------------------------------|
| 0xB6F5F0   | Local player pointer (CPed*)                 |
| 0x18/0x1C  | RpClump* offsets on CPed (early versions)    |
| 0x460/0x468/0x470 | RpClump* offsets on CPed (late/SA:MP)  |
| 0x4D69D0   | CAnimManager::BlendAnimation function        |

---

# Building

See `build.cmd` or `build.ps1` (requires Visual Studio 2022 Build Tools).

```cmd
build.cmd Debug     # Debug build
build.cmd Release   # Release build
```

---

# Future Roadmap

* Auto-detection of stuck animations
* Save/load configuration
* Per-animation blocking
* Direct3D9 overlay menu
* ImGui integration
* More gameplay features
