#pragma once

class GameHook {
public:
    static GameHook& getInstance() {
        static GameHook instance;
        return instance;
    }

    void initialize();
    void update();

private:
    GameHook() : initialized(false), lastKeyTime(0) {}
    bool initialized;
    unsigned long lastKeyTime;
    static const unsigned long KEY_DELAY_MS = 250;
    bool isKeyPressed(int vKey);
};
