#include "pch.h"
#include "AnimFixSystem.h"
#include <cstdio>

#define ADDR_LOCAL_PLAYER          0xB6F5F0
#define ADDR_FUNC_BLEND_ANIM       0x4D69D0

static const unsigned long long COOLDOWN_MS = 1000;

bool AnimFixSystem::isValidPtr(DWORD addr) const {
    return addr >= 0x00100000 && addr < 0x7FFF0000;
}

void AnimFixSystem::initialize() {
    lastClearTime = 0;
    OutputDebugStringA("[AnimFix] Initialized - Press R to clear stuck animations\n");
}

static bool safeRead(DWORD addr, DWORD* outVal) {
    __try {
        *outVal = *(volatile DWORD*)addr;
        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static DWORD findClump(DWORD pedPtr) {
    // RpClump* offsets for CPed structure in GTA SA 1.0 US
    static const DWORD offsets[] = { 0x18, 0x1C, 0x470, 0x460, 0x468 };

    if (pedPtr < 0x00100000 || pedPtr >= 0x7FFF0000) {
        OutputDebugStringA("[AnimFix] Invalid ped pointer in findClump\n");
        return 0;
    }

    for (int i = 0; i < 5; i++) {
        DWORD val;
        if (!safeRead(pedPtr + offsets[i], &val)) {
            continue;
        }
        if (val >= 0x00100000 && val < 0x7FFF0000) {
            // Verify it's readable by doing a test read
            DWORD testVal;
            if (safeRead(val, &testVal)) {
                char buf[128];
                wsprintfA(buf, "[AnimFix] Found clump at offset 0x%X = 0x%X\n", offsets[i], val);
                OutputDebugStringA(buf);
                return val;
            }
        }
    }
    OutputDebugStringA("[AnimFix] No valid clump found\n");
    return 0;
}

static bool tryBlendAnimation(DWORD clump, DWORD group, DWORD animId) {
    __try {
        typedef DWORD*(__cdecl* BlendAnim_t)(DWORD clump, DWORD group, DWORD animId, float blendDelta);
        DWORD* result = ((BlendAnim_t)ADDR_FUNC_BLEND_ANIM)(clump, group, animId, 8.0f);

        char buf[128];
        wsprintfA(buf, "[AnimFix] BlendAnimation(group=%lu, anim=%lu) result=0x%X\n", group, animId, (DWORD)result);
        OutputDebugStringA(buf);
        return (result != nullptr);
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        char buf[128];
        wsprintfA(buf, "[AnimFix] BlendAnimation(group=%lu, anim=%lu) failed (exception)\n", group, animId);
        OutputDebugStringA(buf);
        return false;
    }
}

void AnimFixSystem::clearAllAnimations() {
    unsigned long long now = GetTickCount64();
    if (now - lastClearTime < COOLDOWN_MS) return;
    lastClearTime = now;

    __try {
        DWORD pedPtr;
        if (!safeRead(ADDR_LOCAL_PLAYER, &pedPtr) || !isValidPtr(pedPtr)) {
            OutputDebugStringA("[AnimFix] Cannot read local player pointer\n");
            return;
        }

        DWORD clump = findClump(pedPtr);
        if (!clump) {
            return;
        }

        // Try multiple animation groups to find one that works
        // Group 0 = default/idle, Group 1 = walk, Group 2 = run
        bool anySuccess = false;
        anySuccess |= tryBlendAnimation(clump, 0, 0);
        anySuccess |= tryBlendAnimation(clump, 1, 0);
        anySuccess |= tryBlendAnimation(clump, 2, 0);

        if (anySuccess) {
            OutputDebugStringA("[AnimFix] Animation fix applied successfully\n");
        } else {
            OutputDebugStringA("[AnimFix] All animation blend attempts failed\n");
        }
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        OutputDebugStringA("[AnimFix] Fatal exception in clearAllAnimations\n");
    }
}
