#ifndef PCH_H
#define PCH_H

#include "framework.h"

#include <cstdio>
#include <cstring>

#endif // PCH_H
