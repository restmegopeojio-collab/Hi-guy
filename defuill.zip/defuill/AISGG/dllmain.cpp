#include "pch.h"
#include "AnimFixSystem.h"
#include "GameHook.h"

#include <atomic>

HANDLE hGameThread = NULL;
std::atomic<bool> g_threadRunning(false);

DWORD WINAPI GameLoopThread(LPVOID lpParam) {
    AnimFixSystem::getInstance().initialize();
    GameHook::getInstance().initialize();

    Sleep(3000);
    g_threadRunning.store(true);

    while (g_threadRunning.load()) {
        GameHook::getInstance().update();
        Sleep(16); // ~60 FPS
    }
    return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
        DisableThreadLibraryCalls(hModule);
        hGameThread = CreateThread(NULL, 0, GameLoopThread, NULL, 0, NULL);
        if (!hGameThread) return FALSE;
        break;
    case DLL_PROCESS_DETACH:
        if (hGameThread) {
            g_threadRunning.store(false);
            if (WaitForSingleObject(hGameThread, 3000) == WAIT_TIMEOUT) {
                TerminateThread(hGameThread, 0);
            }
            CloseHandle(hGameThread);
            hGameThread = NULL;
        }
        break;
    }
    return TRUE;
}
