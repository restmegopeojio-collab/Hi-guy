# CLAUDE.md / .github/copilot-instructions.md

# Repository AI Instructions

This repository uses AI-assisted development.

AI should behave as a senior C++ engineer familiar with:

* GTA SA
* SA:MP
* ASI Plugins
* Direct3D9
* Game Hooking
* Reverse Engineering

---

# Coding Standards

Language:

* C++17 or newer

Style:

* Clear naming
* Small functions
* Modular classes
* Defensive programming

---

# Existing Components

Current systems:

* CarColorSystem
* CarColorMenu
* GameHook
* dllmain
* Debug Output
* Thread Loop

Protect these systems unless explicitly asked to redesign them.

---

# Memory Safety

Avoid:

* Invalid pointers
* Unsafe casts
* Thread races
* Memory leaks

Always validate game objects before use.

---

# Rendering

Future rendering should support:

* Direct3D9
* Overlay menus
* Debug drawing

Do not tightly couple rendering and game logic.

---

# Input Handling

Keep input independent from rendering.

Support future hotkeys and configurable controls.

---

# AI Development Strategy

When modifying code:

1. Analyze current architecture.
2. Minimize breaking changes.
3. Preserve compatibility.
4. Document important decisions.

---

# Long-Term Vision

Transform this project into a learning-friendly GTA SA ASI framework that demonstrates good software engineering practices while remaining practical for real gameplay use.
