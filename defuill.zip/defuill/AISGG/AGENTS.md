# AGENTS.md

# AI Development Instructions

You are helping build a long-term GTA SA ASI Plugin.

Do not act as a simple code generator.

Act as a software architect and experienced game plugin developer.

---

# Primary Goal

Build a stable and maintainable GTA SA Animation Fix plugin (AnimFix).

---

# Project Priorities

1. Stability
2. Safety
3. Performance
4. Clean Code
5. Beginner Friendly

---

# Architecture Rules

Prefer:

* Class-based design
* Singleton managers
* Modular systems
* Header / Source separation

Avoid:

* Huge functions
* Copy-paste logic
* Hardcoded memory addresses
* Global mutable state

---

# Hooking Rules

Game hooks should:

* Be isolated
* Be easy to replace
* Fail safely
* Never crash the game

---

# Menu Rules

The menu system should:

* Be independent
* Be reusable
* Support future UI upgrades

---

# Input Rules

Keyboard input should:

* Support key delay
* Prevent spam
* Be frame-rate independent

---

# Threading Rules

Background threads should:

* Start safely
* Shutdown safely
* Avoid race conditions

---

# AI Behavior

Always:

* Explain architecture changes.
* Preserve existing features.
* Improve incrementally.

Never:

* Rewrite the whole project unless requested.
* Remove working systems.
* Introduce unstable hacks.

---

# Future Expansion

Design code to support:

* Direct3D9 rendering
* ImGui integration
* Auto-detection of stuck animations
* Configuration files
* Save / Load system
* Multiple menus
* More gameplay features
